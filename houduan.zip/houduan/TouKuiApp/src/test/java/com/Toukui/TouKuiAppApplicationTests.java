package com.Toukui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouKuiAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
